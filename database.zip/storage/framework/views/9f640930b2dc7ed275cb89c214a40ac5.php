<footer class="d-footer">
    <div class="row align-items-center justify-content-between">
        <div class="col-auto">
            <p class="mb-0">© <?php echo e(date('Y')); ?> <?php echo e(config('company.name')); ?>. Tüm Hakları Saklıdır.</p>
        </div>
        <div class="col-auto">
            <p class="mb-0">
                <iconify-icon icon="solar:phone-outline" class="me-1"></iconify-icon>
                <?php echo e(config('company.contact.phone')); ?>

            </p>
        </div>
    </div>
</footer><?php /**PATH C:\laragon\www\RonexCari\resources\views/components/footer.blade.php ENDPATH**/ ?>