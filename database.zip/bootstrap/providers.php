<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\HostingServiceProvider::class,
];
